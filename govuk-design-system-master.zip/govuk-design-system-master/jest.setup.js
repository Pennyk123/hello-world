/* eslint-env jest */

jest.setTimeout(10000)
