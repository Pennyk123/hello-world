// JavaScript that blocks render before the rest of the page.

// Ensure that HTML5 elements can be styled
import 'html5shiv/dist/html5shiv-printshiv.js'
import 'iframe-resizer/js/ie8.polyfils.min.js'
